NullMoth 3.0 kernel components archived from a tested ASUS G814JV Tahoe x86_64 installation, including its locally built NVRMFB diagnostic variant. Noncommercial distribution. See LICENSE and NOTICE.
This archive is not a complete installer. Install matching original NullMoth 3.0 userspace components and obtain NVIDIA firmware through the upstream installer. No standalone firmware or EFI is packaged here.
Upstream: https://github.com/nullmoth/nvidia-macos-driver/releases/tag/v3.0
